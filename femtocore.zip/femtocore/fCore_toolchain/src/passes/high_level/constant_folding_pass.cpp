// Copyright 2021 University of Nottingham Ningbo China
// Author: Filippo Savi <filssavi@gmail.com>
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//


#include "passes/high_level/constant_folding_pass.hpp"

constant_folding_pass::constant_folding_pass() : pass_base<hl_ast_node>("Constant folding pass"){

}

std::shared_ptr<hl_ast_node> constant_folding_pass::process_leaf(std::shared_ptr<hl_ast_node> element) {
    std::shared_ptr<hl_ast_node> ret_val = element;
    if(element->node_type==hl_ast_node_type_expr){
        std::shared_ptr<hl_expression_node> expression = std::static_pointer_cast<hl_expression_node>(element);
        if(expression_evaluator::is_constant_expression(expression)){
            ret_val =  expression_evaluator::evaluate_expression(expression);
        }
    }
    return ret_val;
}