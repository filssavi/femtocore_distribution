
// Generated from /home/fils/git/fCore_toolchain/src/frontend/asm_grammar.g4 by ANTLR 4.10.1


#include "asm_grammarBaseVisitor.h"


using namespace asm_parser;

