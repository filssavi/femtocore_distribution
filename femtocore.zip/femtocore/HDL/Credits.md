# Credits

This project is made possible by the community surrounding it and especially the wonderful people and projects listed in this document.

## Contributors

- **Filippo Savi:** filssavi@gmail.com
